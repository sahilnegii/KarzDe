package com.lti.repo;

import java.util.List;
import com.lti.model.Admin;
import com.lti.model.Application;
import com.lti.model.Customer;

public interface RepositoryInterface 
{

	//User
	
	
	public int isValidUser(int userId,String userPassword);
	
	public int addLoanApplication(Application application);
	
	public boolean isCustomerPresent(int userId);
	
	
	//Admin
	int registerAdmin(Admin admin);
	
	public int adminLogin(int employeeId,String adminPassword);
	
	public boolean isAdminPresent(int adminId);
	
	public List<Customer> viewAllUsers();
	
	public List<Application> viewAllApplications();
	
	public Customer findAUser(int userId);

	public Customer findById(int id);
	
	Application findByApplicationId(int id);

	public int registerUser(Customer user);
	public boolean isApplicationPresent(Integer appId);

	public void approveApplication(Integer applicationId);

	public void rejectApplication(Integer applicationId);

	public String trackStatusByApplicationId(int id);

	public Admin findAdminById(int adminId);
	
	
}
